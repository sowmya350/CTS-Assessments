using NUnit.Framework;
using UtilLib;
using System;

namespace UtilLib.Tests
{
    [TestFixture]
    public class UrlHostNameParserTests
    {
        private UrlHostNameParser parser;

        [SetUp]
        public void Setup()
        {
            parser = new UrlHostNameParser();
        }

        // ✅ Test 1: Valid URL returns correct host
        [Test]
        public void ParseHostName_ValidUrl_ReturnsHostName()
        {
            string url = "https://www.example.com/page";
            string result = parser.ParseHostName(url);

            Assert.That(result, Is.EqualTo("www.example.com"));
        }

        // ✅ Test 2: Invalid URL throws exception
        [Test]
        public void ParseHostName_InvalidUrl_ThrowsException()
        {
            string url = "not-a-valid-url";

            var ex = Assert.Throws<ArgumentException>(() => parser.ParseHostName(url));
            Assert.That(ex.Message, Is.EqualTo("Invalid URL format"));
        }

        // ✅ Test 3: URL without host returns empty string
        [Test]
        public void ParseHostName_UrlWithoutHost_ReturnsEmpty()
        {
            string url = "file:///C:/temp/test.txt";
            string result = parser.ParseHostName(url);

            Assert.That(result, Is.EqualTo(string.Empty));
        }
    }
}
