using NUnit.Framework;
using System;

namespace CalculatorApp.Tests
{
    [TestFixture]
    public class CalculatorTests
    {
        private MathLibrary math;

        [SetUp]
        public void Setup()
        {
            math = new MathLibrary();
        }

        // Parameterized Subtraction Tests
        [TestCase(10, 5, 5)]
        [TestCase(20, 10, 10)]
        [TestCase(5, 2, 3)]
        public void TestSubtraction(double a, double b, double expected)
        {
            double actual = math.Subtract(a, b);
            Assert.AreEqual(expected, actual);
        }

        // Parameterized Multiplication Tests
        [TestCase(2, 3, 6)]
        [TestCase(5, 5, 25)]
        [TestCase(10, -2, -20)]
        public void TestMultiplication(double a, double b, double expected)
        {
            double actual = math.Multiply(a, b);
            Assert.AreEqual(expected, actual);
        }

        // Parameterized Division Tests
        [TestCase(10, 2, 5)]
        [TestCase(20, 4, 5)]
        public void TestDivision(double a, double b, double expected)
        {
            double actual = math.Divide(a, b);
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TestDivisionByZero()
        {
            try
            {
                math.Divide(10, 0);
                Assert.Fail("Division by zero");
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Division by zero", ex.Message);
                Assert.IsInstanceOf<ArgumentException>(ex);
            }
        }

        // Testing void methods
        [Test]
        public void TestAddAndClear()
        {
            double actual = math.Add(5, 5);
            Assert.AreEqual(10, actual);

            math.AllClear();
            Assert.AreEqual(0, math.GetResult);
        }
    }
}
