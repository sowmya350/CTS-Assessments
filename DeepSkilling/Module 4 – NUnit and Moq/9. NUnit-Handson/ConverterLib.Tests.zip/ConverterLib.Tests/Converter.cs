namespace ConverterLib
{
    public class Converter
    {
        private readonly IDollarToEuroExchangeRateFeed _feed;

        public Converter(IDollarToEuroExchangeRateFeed feed)
        {
            _feed = feed;
        }

        public double USDToEuro(double dollars)
        {
            double rate = _feed.GetExchangeRate();
            return dollars * rate;
        }
    }
}
