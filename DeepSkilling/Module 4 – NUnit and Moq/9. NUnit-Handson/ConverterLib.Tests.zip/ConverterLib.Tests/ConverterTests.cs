using NUnit.Framework;
using ConverterLib;
using Moq;

namespace ConverterLib.Tests
{
    [TestFixture]
    public class ConverterTests
    {
        private Mock<IDollarToEuroExchangeRateFeed> mockFeed;
        private Converter converter;

        [SetUp]
        public void Setup()
        {
            mockFeed = new Mock<IDollarToEuroExchangeRateFeed>();
        }

        // ✅ Happy path test
        [Test]
        public void USDToEuro_ValidRate_ReturnsConvertedValue()
        {
            mockFeed.Setup(f => f.GetExchangeRate()).Returns(0.9); // 1 USD = 0.9 EUR
            converter = new Converter(mockFeed.Object);

            double result = converter.USDToEuro(100);
            Assert.That(result, Is.EqualTo(90));
        }

        // ✅ Different rate test
        [Test]
        public void USDToEuro_DifferentRate_ReturnsConvertedValue()
        {
            mockFeed.Setup(f => f.GetExchangeRate()).Returns(0.8);
            converter = new Converter(mockFeed.Object);

            double result = converter.USDToEuro(50);
            Assert.That(result, Is.EqualTo(40));
        }

        // ✅ Zero rate test
        [Test]
        public void USDToEuro_ZeroRate_ReturnsZero()
        {
            mockFeed.Setup(f => f.GetExchangeRate()).Returns(0.0);
            converter = new Converter(mockFeed.Object);

            double result = converter.USDToEuro(100);
            Assert.That(result, Is.EqualTo(0));
        }

        // ✅ Negative rate test (edge case)
        [Test]
        public void USDToEuro_NegativeRate_ReturnsNegativeValue()
        {
            mockFeed.Setup(f => f.GetExchangeRate()).Returns(-1.0);
            converter = new Converter(mockFeed.Object);

            double result = converter.USDToEuro(10);
            Assert.That(result, Is.EqualTo(-10));
        }
    }
}
