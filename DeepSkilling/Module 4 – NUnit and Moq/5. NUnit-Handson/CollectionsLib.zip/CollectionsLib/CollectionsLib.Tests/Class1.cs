﻿namespace CollectionsLib.Tests;

public class Class1
{

}
