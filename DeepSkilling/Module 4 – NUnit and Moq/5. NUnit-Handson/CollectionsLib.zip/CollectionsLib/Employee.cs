namespace CollectionsLib
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        // ✅ Override Equals & GetHashCode for uniqueness checks
        public override bool Equals(object obj)
        {
            if (obj is Employee other)
                return this.Id == other.Id;
            return false;
        }

        public override int GetHashCode() => Id.GetHashCode();
    }
}
