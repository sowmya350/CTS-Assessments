using NUnit.Framework;
using CollectionsLib;
using System.Collections.Generic;
using System.Linq;

namespace CollectionsLib.Tests
{
    [TestFixture]
    [Category("CollectionsTests")]   // ✅ Custom attribute example
    public class CollectionsManagerTests
    {
        private CollectionsManager manager;

        [SetUp]
        public void Setup()
        {
            manager = new CollectionsManager();
        }

        // ✅ Scenario 1: Ensure no null values
        [Test]
        public void GetEmployees_NoNullValues_AllItemsNotNull()
        {
            var employees = manager.GetEmployees();
            CollectionAssert.AllItemsAreNotNull(employees);
        }

        // ✅ Scenario 2: Employee with ID 100 exists
        [Test]
        public void GetEmployees_EmployeeId100Exists_ReturnsTrue()
        {
            var employees = manager.GetEmployees();
            Assert.That(employees.Any(e => e.Id == 100), Is.True);
        }

        // ✅ Scenario 3: Unique employees
        [Test]
        public void GetEmployees_UniqueEmployees_AllItemsUnique()
        {
            var employees = manager.GetEmployees();
            CollectionAssert.AllItemsAreUnique(employees);
        }

        // ✅ Scenario 4: Compare two collections
        [Test]
        public void GetEmployees_CompareWithPreviousYears_CollectionsAreEqual()
        {
            var employees1 = manager.GetEmployees();
            var employees2 = manager.GetEmployeesWhoJoinedInPreviousYears();

            // Classic Model
            CollectionAssert.AreEqual(employees1, employees2);

            // Constraint Model
            Assert.That(employees1, Is.EquivalentTo(employees2));
        }

        // ✅ Demonstration of [TestCase]
        [TestCase(100, true)]
        [TestCase(999, false)]
        public void GetEmployees_CheckEmployeeExistsById(int id, bool expected)
        {
            var employees = manager.GetEmployees();
            bool exists = employees.Any(e => e.Id == id);
            Assert.That(exists, Is.EqualTo(expected));
        }

        // ✅ Demonstration of [Ignore]
        [Test, Ignore("Demo of Ignore attribute")]
        public void GetEmployees_DemoIgnore()
        {
            Assert.Fail("This test is ignored");
        }
    }
}
