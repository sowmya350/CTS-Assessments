using NUnit.Framework;
using AccountsManagerLib;
using System;

namespace AccountsManagerLib.Tests
{
    [TestFixture]
    public class AccountsManagerTests
    {
        private AccountsManager manager;

        [SetUp]
        public void Setup()
        {
            manager = new AccountsManager();
        }

        // ✅ Valid login test
        [Test]
        public void Login_ValidCredentials_ReturnsWelcomeMessage()
        {
            string result = manager.Login("user_11", "secret@user11");
            Assert.That(result, Is.EqualTo("Welcome user_11!!!"));
        }

        // ✅ Invalid login test
        [Test]
        public void Login_InvalidCredentials_ReturnsErrorMessage()
        {
            string result = manager.Login("user_11", "wrongpass");
            Assert.That(result, Is.EqualTo("Invalid user id/password"));
        }

        // ✅ Missing userId throws exception
        [Test]
        public void Login_MissingUserId_ThrowsArgumentException()
        {
            var ex = Assert.Throws<ArgumentException>(() => manager.Login("", "secret@user11"));
            Assert.That(ex.Message, Is.EqualTo("UserId or Password missing"));
        }

        // ✅ Missing password throws exception
        [Test]
        public void Login_MissingPassword_ThrowsArgumentException()
        {
            var ex = Assert.Throws<ArgumentException>(() => manager.Login("user_11", ""));
            Assert.That(ex.Message, Is.EqualTo("UserId or Password missing"));
        }
    }
}
