using System;

namespace AccountsManagerLib
{
    public class AccountsManager
    {
        public string Login(string userId, string password)
        {
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(password))
                throw new ArgumentException("UserId or Password missing");

            if ((userId == "user_11" && password == "secret@user11") ||
                (userId == "user_22" && password == "secret@user22"))
            {
                return $"Welcome {userId}!!!";
            }

            return "Invalid user id/password";
        }
    }
}
