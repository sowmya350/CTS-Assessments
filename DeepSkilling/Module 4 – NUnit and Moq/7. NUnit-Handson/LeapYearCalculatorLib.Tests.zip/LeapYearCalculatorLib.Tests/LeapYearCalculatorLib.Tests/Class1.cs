﻿namespace LeapYearCalculatorLib.Tests;

public class Class1
{

}
