using NUnit.Framework;
using LeapYearCalculatorLib;

namespace LeapYearCalculatorLib.Tests
{
    [TestFixture]
    public class LeapYearCalculatorTests
    {
        private LeapYearCalculator calc;

        [SetUp]
        public void Setup()
        {
            calc = new LeapYearCalculator();
        }

        // ✅ Parameterized test for leap years
        [TestCase(2000, 1)]   // divisible by 400
        [TestCase(2024, 1)]   // divisible by 4 but not 100
        [TestCase(1900, 0)]   // divisible by 100 but not 400
        [TestCase(2023, 0)]   // not divisible by 4
        [TestCase(1700, -1)]  // invalid year < 1753
        [TestCase(10000, -1)] // invalid year > 9999
        public void CheckLeapYear_YearInput_ReturnsExpected(int year, int expected)
        {
            int result = calc.CheckLeapYear(year);
            Assert.That(result, Is.EqualTo(expected));
        }
    }
}
