using NUnit.Framework;
using FourSeasonsLib;
using System.Collections.Generic;

namespace FourSeasonsLib.Tests
{
    [TestFixture]
    public class SeasonConverterTests
    {
        private SeasonConverter converter;

        [SetUp]
        public void Setup()
        {
            converter = new SeasonConverter();
        }

        // ✅ Straightforward TestCaseSource using IEnumerable<object[]>
        public static IEnumerable<object[]> SeasonTestData()
        {
            yield return new object[] { "February", "Spring - Sunny and pleasant" };
            yield return new object[] { "March", "Spring - Sunny and pleasant" };
            yield return new object[] { "April", "Summer - Hot" };
            yield return new object[] { "June", "Summer - Hot" };
            yield return new object[] { "July", "Monsoon - Wet, hot and humid" };
            yield return new object[] { "September", "Monsoon - Wet, hot and humid" };
            yield return new object[] { "October", "Autumn - Pleasant" };
            yield return new object[] { "November", "Autumn - Pleasant" };
            yield return new object[] { "December", "Winter - Very Cool" };
            yield return new object[] { "January", "Winter - Very Cool" };
        }

        [Test, TestCaseSource(nameof(SeasonTestData))]
        public void GetSeason_ValidMonth_ReturnsExpectedSeason(string month, string expected)
        {
            string result = converter.GetSeason(month);
            Assert.That(result, Is.EqualTo(expected));
        }

        // ✅ Alternate way: TestCaseSource with Dictionary
        public static Dictionary<string, string> SeasonDictionary = new()
        {
            { "February", "Spring - Sunny and pleasant" },
            { "March", "Spring - Sunny and pleasant" },
            { "April", "Summer - Hot" },
            { "May", "Summer - Hot" },
            { "June", "Summer - Hot" },
            { "July", "Monsoon - Wet, hot and humid" },
            { "August", "Monsoon - Wet, hot and humid" },
            { "September", "Monsoon - Wet, hot and humid" },
            { "October", "Autumn - Pleasant" },
            { "November", "Autumn - Pleasant" },
            { "December", "Winter - Very Cool" },
            { "January", "Winter - Very Cool" }
        };

        [Test, TestCaseSource(nameof(SeasonDictionary))]
        public void GetSeason_ValidMonth_UsingDictionary(KeyValuePair<string, string> data)
        {
            string result = converter.GetSeason(data.Key);
            Assert.That(result, Is.EqualTo(data.Value));
        }

        // ✅ Invalid month test
        [Test]
        public void GetSeason_InvalidMonth_ThrowsException()
        {
            var ex = Assert.Throws<System.ArgumentException>(() => converter.GetSeason("InvalidMonth"));
            Assert.That(ex.Message, Is.EqualTo("Invalid month"));
        }
    }
}
