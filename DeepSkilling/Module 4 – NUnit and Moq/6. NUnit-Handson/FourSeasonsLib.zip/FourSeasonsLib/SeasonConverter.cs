using System;

namespace FourSeasonsLib
{
    public class SeasonConverter
    {
        public string GetSeason(string month)
        {
            month = month.ToLower();

            if (month == "february" || month == "march")
                return "Spring - Sunny and pleasant";
            if (month == "april" || month == "may" || month == "june")
                return "Summer - Hot";
            if (month == "july" || month == "august" || month == "september")
                return "Monsoon - Wet, hot and humid";
            if (month == "october" || month == "november")
                return "Autumn - Pleasant";
            if (month == "december" || month == "january")
                return "Winter - Very Cool";

            throw new ArgumentException("Invalid month");
        }
    }
}
