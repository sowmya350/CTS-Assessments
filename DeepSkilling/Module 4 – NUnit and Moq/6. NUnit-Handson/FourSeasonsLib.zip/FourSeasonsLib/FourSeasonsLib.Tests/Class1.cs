﻿namespace FourSeasonsLib.Tests;

public class Class1
{

}
