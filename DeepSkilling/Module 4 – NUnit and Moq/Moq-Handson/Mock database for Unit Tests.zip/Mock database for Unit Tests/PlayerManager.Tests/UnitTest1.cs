﻿using Moq;
using PlayersManagerLib;

namespace PlayerManager.Tests;

[TestFixture]
public class PlayerTests
{
    private Mock<IPlayerMapper> _playerMapperMock = null!;

    [OneTimeSetUp]
    public void Init()
    {
        _playerMapperMock = new Mock<IPlayerMapper>();
    }

    [TestCase("Alice")]
    [TestCase("Bob")]
    public void RegisterNewPlayer_ShouldCreatePlayer_WhenNameIsAvailable(string name)
    {
        _playerMapperMock.Setup(x => x.IsPlayerNameExistsInDb(name)).Returns(false);
        _playerMapperMock.Setup(x => x.AddNewPlayerIntoDb(name));

        var player = Player.RegisterNewPlayer(name, _playerMapperMock.Object);

        Assert.That(player, Is.Not.Null);
        Assert.That(player.Name, Is.EqualTo(name));
        Assert.That(player.Age, Is.EqualTo(23));
        Assert.That(player.Country, Is.EqualTo("India"));
        Assert.That(player.NoOfMatches, Is.EqualTo(30));

        _playerMapperMock.Verify(x => x.IsPlayerNameExistsInDb(name), Times.Once);
        _playerMapperMock.Verify(x => x.AddNewPlayerIntoDb(name), Times.Once);
    }

    [TestCase("")]
    [TestCase("   ")]
    [TestCase(null)]
    public void RegisterNewPlayer_ShouldThrow_WhenNameIsEmpty(string? name)
    {
        Assert.Throws<ArgumentException>(() => Player.RegisterNewPlayer(name!, _playerMapperMock.Object));
    }
}
