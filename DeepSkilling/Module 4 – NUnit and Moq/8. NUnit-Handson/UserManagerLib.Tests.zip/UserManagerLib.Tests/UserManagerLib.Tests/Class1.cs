﻿namespace UserManagerLib.Tests;

public class Class1
{

}
