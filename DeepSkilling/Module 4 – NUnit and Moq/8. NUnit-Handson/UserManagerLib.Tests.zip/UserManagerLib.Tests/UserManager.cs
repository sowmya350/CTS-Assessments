using System;

namespace UserManagerLib
{
    public class UserManager
    {
        public string PANCardNo { get; set; }

        public string CreateUser()
        {
            if (string.IsNullOrEmpty(PANCardNo))
                throw new NullReferenceException("PANCardNo cannot be null or empty");

            if (PANCardNo.Length != 10)
                throw new FormatException("PANCardNo must be exactly 10 characters");

            return "User created successfully";
        }
    }
}
