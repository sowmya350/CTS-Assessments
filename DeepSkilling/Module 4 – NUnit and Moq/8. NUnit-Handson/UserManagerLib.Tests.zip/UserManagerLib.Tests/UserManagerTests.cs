using NUnit.Framework;
using UserManagerLib;
using System;

namespace UserManagerLib.Tests
{
    [TestFixture]
    public class UserManagerTests
    {
        private UserManager manager;

        [SetUp]
        public void Setup()
        {
            manager = new UserManager();
        }

        // ✅ Happy path test
        [Test]
        public void CreateUser_ValidPANCardNo_ReturnsSuccessMessage()
        {
            manager.PANCardNo = "ABCDE12345";
            string result = manager.CreateUser();
            Assert.That(result, Is.EqualTo("User created successfully"));
        }

        // ✅ NullReferenceException test
        [Test]
        public void CreateUser_NullPANCardNo_ThrowsNullReferenceException()
        {
            manager.PANCardNo = null;
            var ex = Assert.Throws<NullReferenceException>(() => manager.CreateUser());
            Assert.That(ex.Message, Is.EqualTo("PANCardNo cannot be null or empty"));
        }

        // ✅ Empty string test
        [Test]
        public void CreateUser_EmptyPANCardNo_ThrowsNullReferenceException()
        {
            manager.PANCardNo = "";
            var ex = Assert.Throws<NullReferenceException>(() => manager.CreateUser());
            Assert.That(ex.Message, Is.EqualTo("PANCardNo cannot be null or empty"));
        }

        // ✅ FormatException test
        [Test]
        public void CreateUser_InvalidLengthPANCardNo_ThrowsFormatException()
        {
            manager.PANCardNo = "ABC123"; // only 6 chars
            var ex = Assert.Throws<FormatException>(() => manager.CreateUser());
            Assert.That(ex.Message, Is.EqualTo("PANCardNo must be exactly 10 characters"));
        }
    }
}
