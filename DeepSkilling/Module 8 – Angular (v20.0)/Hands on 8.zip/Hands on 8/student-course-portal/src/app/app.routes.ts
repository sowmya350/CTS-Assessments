import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { CourseListComponent } from './pages/course-list/course-list.component';
import { EnrollmentFormComponent } from './pages/enrollment-form/enrollment-form.component';
import { StudentProfileComponent } from './components/student-profile/student-profile.component';
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'courses', component: CourseListComponent },
  { path: 'enroll', component: EnrollmentFormComponent },
  { path: 'profile', component: StudentProfileComponent, canActivate: [AuthGuard] },
  { path: '**', redirectTo: '' },
];
