import { Injectable } from '@angular/core';
import { Course } from '../models/course.model';

@Injectable({ providedIn: 'root' })
export class CourseService {
  private courses: Course[] = [
    { id: 1, name: 'Math', code: 'M101', credits: 3, gradeStatus: 'passed' },
    { id: 2, name: 'Physics', code: 'P102', credits: 4, gradeStatus: 'failed' },
    { id: 3, name: 'Chemistry', code: 'C103', credits: 2, gradeStatus: 'pending' },
  ];

  getCourses(): Course[] {
    return this.courses;
  }

  getCourseById(id: number): Course | undefined {
    return this.courses.find((course) => course.id === id);
  }

  addCourse(course: Course): void {
    this.courses.push(course);
  }
}
