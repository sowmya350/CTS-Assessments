import { describe, expect, it } from 'vitest';
import { EnrollmentService } from './enrollment.service';
import { CourseService } from './course.service';

describe('EnrollmentService', () => {
  it('toggles enrollment state for a course', () => {
    const courseService = new CourseService();
    const service = new EnrollmentService(courseService);

    expect(service.isEnrolled(1)).toBe(false);

    service.enroll(1);
    expect(service.isEnrolled(1)).toBe(true);

    service.unenroll(1);
    expect(service.isEnrolled(1)).toBe(false);
  });
});
