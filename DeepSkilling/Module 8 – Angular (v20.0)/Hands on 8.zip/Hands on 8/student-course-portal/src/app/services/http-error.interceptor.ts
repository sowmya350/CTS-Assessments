import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    console.log('HTTP Request:', req.url);

    return next.handle(req).pipe(
      tap(event => {
        // log successful responses if needed
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('HTTP Error:', error.message);
        alert('An error occurred: ' + error.message);
        return throwError(() => error);
      })
    );
  }
}
