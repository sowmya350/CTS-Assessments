import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CourseService } from '../../services/course.service';
import { EnrollmentService } from '../../services/enrollment.service';

@Component({
  selector: 'app-enrollment-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './enrollment-form.component.html',
  styleUrls: ['./enrollment-form.component.css'],
})
export class EnrollmentFormComponent implements OnInit {
  courses = [] as any[];
  selectedId: number | null = null;
  message = '';

  constructor(
    private courseService: CourseService,
    private enrollmentService: EnrollmentService
  ) {}

  ngOnInit(): void {
    this.courses = this.courseService.getCourses();
  }

  enroll() {
    if (!this.selectedId) {
      this.message = 'Please select a course to enroll.';
      return;
    }

    this.enrollmentService.enroll(this.selectedId);
    const course = this.courseService.getCourseById(this.selectedId);
    this.message = course ? `Enrolled in ${course.name}` : 'Enrolled.';
  }
}
