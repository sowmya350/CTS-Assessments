import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';
import * as CourseActions from '../../store/actions/course.actions';
import { selectAllCourses, selectEnrolledCourseIds } from '../../store/selectors/course.selectors';
import { Observable } from 'rxjs';
import { Course } from '../../models/course.model';

@Component({
  selector: 'app-course-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css'],
})
export class CourseListComponent implements OnInit {
  courses$!: Observable<Course[]>;
  enrolledIds$!: Observable<number[]>;

  constructor(private store: Store) {}

  ngOnInit(): void {
    this.courses$ = this.store.select(selectAllCourses);
    this.enrolledIds$ = this.store.select(selectEnrolledCourseIds);
    this.store.dispatch(CourseActions.loadCourses());
  }

  enroll(courseId: number): void {
    this.store.dispatch(CourseActions.enrollCourse({ courseId }));
  }

  unenroll(courseId: number): void {
    this.store.dispatch(CourseActions.unenrollCourse({ courseId }));
  }
}
