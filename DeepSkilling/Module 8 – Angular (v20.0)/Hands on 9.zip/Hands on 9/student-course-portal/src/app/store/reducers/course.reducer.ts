import { createReducer, on } from '@ngrx/store';
import * as CourseActions from '../actions/course.actions';
import { Course } from '../../models/course.model';

export interface CourseState {
  courses: Course[];
  enrolledCourseIds: number[];
  error: any;
}

export const initialState: CourseState = {
  courses: [],
  enrolledCourseIds: [],
  error: null,
};

export const courseReducer = createReducer(
  initialState,
  on(CourseActions.loadCoursesSuccess, (state, { courses }) => ({ ...state, courses })),
  on(CourseActions.loadCoursesFailure, (state, { error }) => ({ ...state, error })),
  on(CourseActions.enrollCourse, (state, { courseId }) => ({
    ...state,
    enrolledCourseIds: [...state.enrolledCourseIds, courseId],
  })),
  on(CourseActions.unenrollCourse, (state, { courseId }) => ({
    ...state,
    enrolledCourseIds: state.enrolledCourseIds.filter((id) => id !== courseId),
  }))
);
