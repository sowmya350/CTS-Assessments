import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CourseState } from '../reducers/course.reducer';

export const selectCourseState = createFeatureSelector<CourseState>('courses');

export const selectAllCourses = createSelector(selectCourseState, (state) => state.courses);
export const selectEnrolledCourseIds = createSelector(selectCourseState, (state) => state.enrolledCourseIds);
