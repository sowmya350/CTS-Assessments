import { describe, expect, it } from 'vitest';
import { courseReducer, initialState } from './course.reducer';
import * as CourseActions from '../actions/course.actions';

describe('CourseReducer', () => {
  it('should enroll a course', () => {
    const action = CourseActions.enrollCourse({ courseId: 1 });
    const state = courseReducer(initialState, action);
    expect(state.enrolledCourseIds).toContain(1);
  });

  it('should unenroll a course', () => {
    const preloadedState = { ...initialState, enrolledCourseIds: [1, 2] };
    const action = CourseActions.unenrollCourse({ courseId: 1 });
    const state = courseReducer(preloadedState, action);
    expect(state.enrolledCourseIds).not.toContain(1);
    expect(state.enrolledCourseIds).toContain(2);
  });
});
