import { describe, expect, it, beforeEach } from 'vitest';
import { CourseService } from './course.service';

describe('CourseService', () => {
  let service: CourseService;

  beforeEach(() => {
    service = new CourseService();
  });

  it('should return all courses', () => {
    const courses = service.getCourses();
    expect(courses.length).toBeGreaterThan(0);
  });

  it('should return a course by id', () => {
    const course = service.getCourseById(1);
    expect(course).toBeDefined();
    expect(course?.code).toBe('M101');
  });

  it('should add a new course', () => {
    const initialLength = service.getCourses().length;
    service.addCourse({ id: 4, name: 'Biology', code: 'B104', credits: 3, gradeStatus: 'pending' });
    expect(service.getCourses().length).toBe(initialLength + 1);
  });
});
